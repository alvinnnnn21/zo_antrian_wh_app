import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

BoxDecoration decoration = BoxDecoration(
    border: Border.all(), borderRadius: BorderRadius.all(Radius.circular(15)));

EdgeInsets padding = EdgeInsets.all(10);
